package chat

import (
	"time"
)

type Message struct {
	ID        string    `json:"id"`
	Text      string    `json:"text"`
	CreatedBy string    `json:"createdBy"`
	CreatedAt time.Time `json:"createdAt"`
}

type ProductSku string

const (
	ProductSkuTrial ProductSku = "Trial"
)

type ChatAPI struct {
	ID string `json:"id"`
}
