package singlefile

type FieldsOrderInput struct {
	FirstField *string `json:"firstField"`
}
