package singlefile

type RecursiveInputSlice struct {
	Self []RecursiveInputSlice
}
