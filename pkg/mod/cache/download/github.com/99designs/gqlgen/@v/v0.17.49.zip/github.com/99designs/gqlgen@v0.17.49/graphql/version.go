package graphql

const Version = "v0.17.49"
