package a

var A = "A"
