package b

import "github.com/99designs/gqlgen/internal/code/testdata/a"

var B = a.A + " B"
