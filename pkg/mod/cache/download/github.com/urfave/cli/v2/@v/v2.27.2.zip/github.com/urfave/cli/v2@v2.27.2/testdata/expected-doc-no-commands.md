# NAME

greet - Some app

# SYNOPSIS

greet

```
[--another-flag|-b]
[--flag|--fl|-f]=[value]
[--socket|-s]=[value]
```

# DESCRIPTION

Description of the application.

**Usage**:

```
app [first_arg] [second_arg]
```

# GLOBAL OPTIONS

**--another-flag, -b**: another usage text

**--flag, --fl, -f**="": 

**--socket, -s**="": some 'usage' text (default: /some/path)

